from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.template import loader
from django.core.files.storage import FileSystemStorage
import spacy
import pandas as pd
import string
from spacy.lang.en.stop_words import STOP_WORDS
from spacy.lang.en import English
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.base import TransformerMixin
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC
from sklearn.model_selection import train_test_split
import numpy as np
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.models import load_model


class Proyecto():
    imgr = None
    ruta = None
    oracion = []

    def index(self, request):
        template = loader.get_template('index.html')

        if request.method == "POST":

            request_file = request.FILES['document'] if 'document' in request.FILES else None
            if request_file:
                fs = FileSystemStorage()

                file = fs.save(request_file.name, request_file)
                self.imgr = file
                fileurl = fs.url(file)
                self.ruta = fileurl

        data = {

            "titulo": "Clasificador de Imagenes",
            "subtitulo": "- Carga  de Imagenes",

        }

        return HttpResponse(template.render(data, request))

    def resultado(self, request):

        template = loader.get_template('resultado.html')

        longitud, altura = 150, 150
        modelo = './modelo/modelo.h5'
        pesos_modelo = './modelo/pesos.h5'
        cnn = load_model(modelo)
        cnn.load_weights(pesos_modelo)

        def predict(file):
            x = load_img(file, target_size=(longitud, altura))
            x = img_to_array(x)
            x = np.expand_dims(x, axis=0)
            array = cnn.predict(x)
            result = array[0]
            answer = np.argmax(result)
            if answer == 0:
                answer = "Caballo"
            elif answer == 1:
                answer = "Elefante"
            elif answer == 2:
                answer = "Gallina"
            elif answer == 3:
                answer = "Gato"
            elif answer == 4:
                answer = "Perro"

            return answer

        self.ruta = "imagenes/" + self.imgr
        self.imgr = "static/imagenes/" + self.imgr

        resultado = predict(self.imgr)

        data = {

            "titulo": "Resultado",
            "subtitulo": "- Clasificador de imagenes",
            "prediccion": resultado,
            "imagen": self.ruta

        }

        return HttpResponse(template.render(data))

    def analisis(self, request):

        template = loader.get_template('analisis.html')

        data = {
            "lista": "Lista de oraciones",
            "titulo": "Modelo",
            "subtitulo": "- Analisis de sentimiento",
            "oracion": self.oracion,

        }

        return HttpResponse(template.render(data))

    def resultado2(self, request):

        template = loader.get_template('resultado2.html')
        self.oracion.append(request.GET["oracion"])
        nlp = spacy.load('en_core_web_sm')
        punctuations = string.punctuation
        parser = English()
        stopwords = list(STOP_WORDS)

        df = pd.read_csv("sentimentdataset.csv")

        def spacy_tokenizer(sentence):
            mytokens = parser(sentence)
            mytokens = [word.lemma_.lower().strip() if word.lemma_ != "-PRON-" else word.lower_ for word in mytokens]
            mytokens = [word for word in mytokens if word not in stopwords and word not in punctuations]
            return mytokens

        class predictors(TransformerMixin):

            def transform(self, X, **transform_params):
                return [clean_text(text) for text in X]

            def fit(self, X, y=None, **fit_params):
                return self

            def get_params(self, deep=True):
                return {}

        def clean_text(text):
            return text.strip().lower()

        vectorizer = CountVectorizer(tokenizer=spacy_tokenizer, ngram_range=(1, 1))
        classifier = LinearSVC()

        tfvectorizer = TfidfVectorizer(tokenizer=spacy_tokenizer)

        X = df['Message']
        ylabels = df['Target']

        X_train, X_test, y_train, y_test = train_test_split(X, ylabels, test_size=0.2, random_state=42)

        pipe = Pipeline([("cleaner", predictors()),
                         ('vectorizer', vectorizer),
                         ('classifier', classifier)])
        pipe.fit(X_train, y_train)
        sample_prediction = pipe.predict(X_test)

        result = (pipe.predict(self.oracion))
        for i in self.oracion:
            print(i)
        # if result == 0:
        #   result = "Negativa"
        # elif result == 1:
        #   result = "Positiva"

        data = {
            "titulo": "Resultado",
            "subtitulo": "- Analisis de sentimiento",
            "sentimiento": result,
            "oracion": self.oracion,
            "lista": "Lista de oraciones",
        }
        return HttpResponse(template.render(data))
