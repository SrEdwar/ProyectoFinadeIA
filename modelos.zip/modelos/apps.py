from django.apps import AppConfig


class ModelosConfig(AppConfig):
    name = 'modelos'
